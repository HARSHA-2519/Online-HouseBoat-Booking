﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HOUSEBOATMANAGEMENT_View_Enquiry : System.Web.UI.Page
{
    BoatBookingClass Equ = new BoatBookingClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["HOUSEBOATADMIN"] == null)
        {
            Response.Redirect("~/LOGIN/Login.aspx");
        }
        else
        {
            Equ.BoatConnection();
            if (!IsPostBack)
            {
                BindEquiry();
            }
        }
    }
    public void BindEquiry()
    {
        Equ.BoatQuery = @"SELECT Enq_id, Enq_name, Email, Phone, Msg, Status FROM ENQUIRY";
        Equ.BoatGetDataset(Equ.BoatQuery);
        gvEnquriy.DataSource = Equ.BoatDs;
        gvEnquriy.DataBind();
    }

}
