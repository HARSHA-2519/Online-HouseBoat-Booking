﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CUSTOMER_Package_Booking : System.Web.UI.Page
{
    BoatBookingClass PackBook = new BoatBookingClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Cust_id"] == null)
        {
            Response.Redirect("~/LOGIN/Login.aspx");
        }
        else
        {
            PackBook.BoatConnection();
            if (!IsPostBack)
            {
                //PopulateImage();
                BindPackBook();
            }
        }
    }
    public void BindPackBook()
    {
        PackBook.BoatQuery = "SELECT PACKAGES.Pack_name, PACKAGES.Pack_id, PACKAGES.Tot_days, PACKAGES.Image, PACKAGES.Duration, HOUSE_BOAT_REG.Boatname, PACKAGES.Rate FROM PACKAGES INNER JOIN HOUSE_BOAT_REG ON PACKAGES.Boat_id = HOUSE_BOAT_REG.Boat_id";
        PackBook.BoatGetDataset(PackBook.BoatQuery);
        dlPackBook.DataSource = PackBook.BoatDs;
        dlPackBook.DataBind();

    }
    protected void dlPackBook_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "More")
        {
            Session["packid"] = dlPackBook.DataKeys[e.Item.ItemIndex].ToString();
            Response.Redirect("~/CUSTOMER/PackageDetails.aspx");
        }
    }
}