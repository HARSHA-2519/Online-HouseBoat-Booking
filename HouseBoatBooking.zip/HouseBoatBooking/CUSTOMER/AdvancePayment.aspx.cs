﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CUSTOMER_AdvancePayment : System.Web.UI.Page
{
    BoatBookingClass AdvPayment = new BoatBookingClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Cust_id"] == null)
        {
            Response.Redirect("~/LOGIN/Login.aspx");
        }
        else
        {
            AdvPayment.BoatConnection();
            if (Application["With_Card"] != null)
            {
                txtPayType.Text = Application["With_Card"].ToString();
            }
            if (Application["bid"] != null)
            {
                txtBoatName.Text = Application["bid"].ToString();
            }
            if (Application["Bookid"] != null)
            {
                txtBookingId.Text = Application["Bookid"].ToString();
            }
        }
    }
    //public void BookingID()
    //{
    //    AdvPayment.BoatQuery = "select Book_id from BOAT_BOOKING ";
    //    AdvPayment.BoatReadData(AdvPayment.BoatQuery);
    //    if (AdvPayment.BoatDr.Read())
    //    {
    //        Application["Book_Id"] = Convert.ToInt32(AdvPayment.BoatDr[0].ToString());
    //        AdvPayment.BoatDr.Close();
    //    }
    //    AdvPayment.BoatDr.Close();

    //}
    protected void btnPay_Click(object sender, EventArgs e)
    {
        AdvPayment.BoatQuery = "Insert into ADV_PAY values('" + Application["Bookid"] + "','" + System.DateTime.Now.ToString("MM/dd/yy") + "','" + txtPayType.Text + "','" + ddlCardType.SelectedItem.Text + "','" + txtCardNumber.Text + "','" + txtExpireDate.Text + "'," + txtAdvAmt.Text + ",'Paid')";
        AdvPayment.BoatWriteData(AdvPayment.BoatQuery);
        Response.Redirect("~/CUSTOMER/House_Boat_Booking_Package.aspx?Book_id='" + Application["Bookid"] + "'");
        //Response.Write("<script>alert('Data Submitted!!!')</script>");
    }
}