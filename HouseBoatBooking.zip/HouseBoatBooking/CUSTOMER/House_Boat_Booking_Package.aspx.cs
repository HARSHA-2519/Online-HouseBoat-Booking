﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CUSTOMER_House_Boat_Booking_Package : System.Web.UI.Page
{
    BoatBookingClass BoatBookingPack = new BoatBookingClass();
    int count;
    protected void Page_Load(object sender, EventArgs e)
    {
        BoatBookingPack.BoatConnection();
        if (Application["pname"] != null)
        {          
            txtPackaName.Text= Application["pname"].ToString();
        }
        if (Application["bname"] != null)
        {
            txtBoatName.Text = Application["bname"].ToString();
        }

        // Generate auto primary key
        BoatBookingPack.BoatQuery = "select count(*) from BOAT_BOOKING";
        BoatBookingPack.BoatReadData(BoatBookingPack.BoatQuery);
        BoatBookingPack.BoatDr.Close();
        count = Convert.ToInt16(BoatBookingPack.BoatScalar(BoatBookingPack.BoatQuery)) + 1;
        txtBookingId.Text = "HBB00" + count;
        Application["Bookid"] = txtBookingId.Text;
        BoatBookingPack.BoatDr.Close();

        if (HttpContext.Current.Session["Cust_id"] == null)
        {
            Response.Redirect("~/LOGIN/Login.aspx");
        }
        txtAdvPay.Visible = false;
        lblFr.Visible = false;
        lblTo.Visible = false;
        CardPaymentPanel.Visible = false;
        if (!IsPostBack)
        {
            BoatID();
            Rate();
            PackID();
            CustomerName();
        }
        
    }
    protected void btnBook_Click(object sender, EventArgs e)
    {
        try
        {
            if (rblAdvPayment.SelectedItem.Text == "CARDLESS")
            {
                BoatBookingPack.BoatQuery = "Insert into Boat_Booking(Book_id,Boat_id,Pack_or_not,Pack_id,Cust_id,Tot_memb,Tot_adults,Tot_child,From_date,To_date,Adv_amt,Book_date,Total_amt,Status) values('" + Application["Bookid"] + "'," + Application["Boat_Id"] + ",'Yes'," + Application["Pack_id"] + ",'" + Session["Cust_id"] + "'," + txtTotalMember.Text + "," + txtTotalAdults.Text + "," + txtTotalChild.Text + ",'" + txtFromDate.Text + "','" + txtToDate.Text + "'," + txtAdvPay.Text + ",'" + System.DateTime.Now.ToString("MM/dd/yy") + "'," + txtTotalAmount.Text + ",'New Booking')";
                BoatBookingPack.BoatWriteData(BoatBookingPack.BoatQuery);
                Response.Write("<script>alert('Data Submitted!!!')</script>");
                Server.Transfer("PaymentRecepit_Without_Package.aspx?Book_id='" + Application["Bookid"] + "' and Boat_id='" + Application["bname"] + "'");
            }
            else
            {
                BoatBookingPack.BoatQuery = "Insert into Boat_Booking(Book_id,Boat_id,Pack_or_not,Pack_id,Cust_id,Tot_memb,Tot_adults,Tot_child,From_date,To_date,Adv_amt,Book_date,Total_amt,Status) values('" + Application["Bookid"] + "'," + Application["Boat_Id"] + ",'Yes'," + Application["Pack_id"] + ",'" + Session["Cust_id"] + "'," + txtTotalMember.Text + "," + txtTotalAdults.Text + "," + txtTotalChild.Text + ",'" + txtFromDate.Text + "','" + txtToDate.Text + "'," + txtAdvAmt.Text + ",'" + System.DateTime.Now.ToString("MM/dd/yy") + "'," + txtTotalAmount.Text + ",'New Booking')";
                BoatBookingPack.BoatWriteData(BoatBookingPack.BoatQuery);
                Response.Write("<script>alert('Data Submitted!!!')</script>");
                Server.Transfer("Payment_Recepit.aspx?Book_id='" + Application["Bookid"] + "' and Boat_id='"+ Application["bname"] + "'");
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert(" + ex.ToString() + ")</script>");
        }
        finally
        {
            BoatBookingPack.BoatCon.Close();
            BoatBookingPack.BoatCon.Dispose();
            BoatBookingPack.Boatcmd.Dispose();
        }
    }
    public void CustomerName()
    {
        BoatBookingPack.BoatQuery = "select Name from CUSTOMER_REG where Cust_id='"+Session["Cust_id"] +"' ";
        BoatBookingPack.BoatReadData(BoatBookingPack.BoatQuery);
        if (BoatBookingPack.BoatDr.Read())
        {
            txtCustomerName.Text =BoatBookingPack.BoatDr[0].ToString();
            BoatBookingPack.BoatDr.Close();
        }
        BoatBookingPack.BoatDr.Close();
    }
    public void BoatID()
    {
        BoatBookingPack.BoatQuery = "select Boat_id from HOUSE_BOAT_REG ";
        BoatBookingPack.BoatReadData(BoatBookingPack.BoatQuery);
        if (BoatBookingPack.BoatDr.Read())
        {
            Application["Boat_Id"] = Convert.ToInt32(BoatBookingPack.BoatDr[0].ToString());
            BoatBookingPack.BoatDr.Close();
        }
        BoatBookingPack.BoatDr.Close();
    }
    public void PackID()
    {
        BoatBookingPack.BoatQuery = "select Pack_id from PACKAGES where Boat_id="+ Application["Boat_Id"] + " ";
        BoatBookingPack.BoatReadData(BoatBookingPack.BoatQuery);
        if (BoatBookingPack.BoatDr.Read())
        {
            Application["Pack_id"] = Convert.ToInt32(BoatBookingPack.BoatDr[0].ToString());
            BoatBookingPack.BoatDr.Close();
        }
        BoatBookingPack.BoatDr.Close();
    }
    public void Rate()
    {
        BoatBookingPack.BoatQuery = "select Rate,Valid_From,Valid_to_dt from PACKAGES where Boat_id='"+ Application["Boat_Id"] + "'";
        BoatBookingPack.BoatReadData(BoatBookingPack.BoatQuery);
        if (BoatBookingPack.BoatDr.Read())
        {
            Application["Rate"] = Convert.ToInt32(BoatBookingPack.BoatDr[0].ToString());
            txtFromDate.Text =Convert.ToDateTime( BoatBookingPack.BoatDr[1]).ToString("yyyy/MM/dd");
            lblFr.Text = txtFromDate.Text;
            txtToDate.Text = Convert.ToDateTime(BoatBookingPack.BoatDr[2]).ToString("yyyy/MM/dd");
            lblTo.Text = txtToDate.Text;
            BoatBookingPack.BoatDr.Close();
        }
        BoatBookingPack.BoatDr.Close();
    }
    protected void rblAdvPayment_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rblAdvPayment.SelectedItem.Text == "CARDLESS")
        {
            txtAdvPay.Visible = true;
        }
        else
        {
            CardPaymentPanel.Visible = true;
            txtPayType.Text = rblAdvPayment.SelectedItem.Text;
        }

    }
    protected void txtAdvPay_TextChanged(object sender, EventArgs e)
    {
       txtTotalAmount.Text= Convert.ToString(Convert.ToInt32(Application["Rate"]) - Convert.ToInt32(txtAdvPay.Text));
    }

    protected void btnPayNow_Click(object sender, EventArgs e)
    {
        try
        {
            BoatBookingPack.BoatDr.Close();
            BoatBookingPack.BoatQuery = "Insert into ADV_PAY values('" + Application["Bookid"] + "','" + txtBankName.Text + "','" + System.DateTime.Now.ToString("MM/dd/yy") + "','" + txtPayType.Text + "','" + ddlCardType.SelectedItem.Text + "','" + txtCardNumber.Text + "','" + txtExpireDate.Text + "'," + txtAdvAmt.Text + ",'Paid')";
            BoatBookingPack.BoatWriteData(BoatBookingPack.BoatQuery);
            CardPaymentPanel.Visible = false;
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert(" + ex.ToString() + ")</script>");
        }
        finally
        {
            BoatBookingPack.BoatCon.Close();
            BoatBookingPack.BoatCon.Dispose();
            BoatBookingPack.Boatcmd.Dispose();
        }
    }

    protected void txtAdvAmt_TextChanged(object sender, EventArgs e)
    {
        txtTotalAmount.Text = Convert.ToString(Convert.ToInt32(Application["Rate"]) - Convert.ToInt32(txtAdvAmt.Text));
    }

    protected void txtTotalChild_TextChanged(object sender, EventArgs e)
    {
        txtTotalMember.Text = Convert.ToString(Convert.ToInt32(txtTotalAdults.Text) + Convert.ToInt32(txtTotalChild.Text));
    }

    protected void txtFromDate_TextChanged(object sender, EventArgs e)
    {
        DateTime Date1 = Convert.ToDateTime(txtFromDate.Text);
        DateTime date2 = Convert.ToDateTime(lblFr.Text);
        DateTime date3 = Convert.ToDateTime(lblTo.Text);
        if (Date1 < date2)
        {
            Response.Write("<script>alert('No Booking date.Plz select date between\\n" + date2.ToString("dd - MMM") + " & " + date3.ToString("dd - MMM") + ".')</script>");
        }
    }

    protected void txtToDate_TextChanged(object sender, EventArgs e)
    {
        DateTime Date1 = Convert.ToDateTime(txtToDate.Text);
        DateTime date2 = Convert.ToDateTime(lblFr.Text);
        DateTime date3 = Convert.ToDateTime(lblTo.Text);
        if (Date1 > date3)
        {
            Response.Write("<script>alert('No Booking date.Plz select date between\\n" + date2.ToString("dd - MMM") + " & " + date3.ToString("dd - MMM") + ".')</script>");
        }
    }
}