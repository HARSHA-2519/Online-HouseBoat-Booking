﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LOGIN_HouseBoat_Admin_Registration : System.Web.UI.Page
{
    BoatBookingClass HouseAdminReg = new BoatBookingClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        HouseAdminReg.BoatConnection();
        Session["AdminId"] = HouseAdminReg.BoatDr["0"];
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        HouseAdminReg.BoatQuery = "Select * from HB_ADMIN where Name='" + txtName.Text + "' and Address_Line1='"+txtAddress1.Text+"' and Email='"+txtEmail.Text+"'";
        HouseAdminReg.BoatReadData(HouseAdminReg.BoatQuery);
        if (HouseAdminReg.BoatDr.Read())
        {
            HouseAdminReg.BoatDr.Close();
            Response.Write("<script>alert('Data Already Exit')</script>");
        }
        else
        {

            
            HouseAdminReg.BoatDr.Close();
            //Insert username and password into Login table
            HouseAdminReg.BoatQuery = "insert into LOGIN values('" + txtUsername.Text + "','" + txtPassword.Text + "',2)";
            HouseAdminReg.BoatWriteData(HouseAdminReg.BoatQuery);
            HouseAdminReg.BoatQuery = "select @@identity";
            HouseAdminReg.BoatScalar(HouseAdminReg.BoatQuery);
            HouseAdminReg.BoatQuery = "Insert into HB_ADMIN values('" + txtName.Text + "','"+txtAddress1.Text+"','"+txtAddress2.Text+"','"+txtEmail.Text+"',"+txtMobile.Text+",'"+rblGender.SelectedValue+"','"+System.DateTime.Now.ToString("MM/dd/yy")+"',"+ HouseAdminReg.Boatsid+ ",'NEW')";
            HouseAdminReg.BoatWriteData(HouseAdminReg.BoatQuery);
           Response.Write("<script>alert('Data Submitted')</script>");
            Server.Transfer("Login.aspx");
        }
        Clear();
       // Response.Redirect("~/LOGIN/Login.aspx");
    }
    public void Clear()
    {
        txtAddress1.Text = "";
        txtAddress2.Text = "";
        txtConfirmPassword.Text = "";
        txtEmail.Text = "";
        txtMobile.Text = "";
        txtName.Text = "";
        txtPassword.Text = "";
        txtUsername.Text = "";
        rblGender.SelectedIndex = -1;
    }
}
